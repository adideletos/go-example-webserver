# go-example-webserver

Simple Go webserver running in a Docker container.
# go-example-webserver
